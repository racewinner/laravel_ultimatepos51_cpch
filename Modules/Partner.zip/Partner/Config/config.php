<?php

return [
    'name' => 'Partner'
];
